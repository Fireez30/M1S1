#include <iostream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string>
#include <ctime>
#include <unistd.h>
#include <sys/sem.h>
using namespace std;

int main(){

	key_t cle;
	int f_id;

	struct sembuf opv;
	srand(time(NULL));
	int temps = 0;


	union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *__buf;
} arg;
	unsigned short array2[1];
	cle = ftok("docufile",3);
	f_id = semget(cle,1,0666); 
	if ( f_id == -1) {perror("erreur create");}

	cout << "id du tableau de semaphores : " << f_id << endl;
	opv.sem_num=0;
	opv.sem_op=-1;
	opv.sem_flg=0;


	while (true) {
		int temps = rand() %4;
		
		sleep(temps);
		
		if ( semop(f_id,&opv,1) == -1) {perror("erreur operation");}
	
		cout << "Entrée" << endl;
	semctl(f_id,0,GETALL,&array2);
	cout << "Nb places :" << array2[0] << endl;
	}


	return 0;
}