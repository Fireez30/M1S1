#include <iostream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string>
#include <unistd.h>
#include <sys/sem.h>

using namespace std;

/*typedef struct s_sembuf {
	unsigned short sem_num;
	short sem_op;
	short sem_flg;
} sembuf;
*/



int main(){

	struct sembuf opv;

union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *__buf;
} arg_ctrl;

	key_t cle;
	int f_id;
	int nbrdv;
	cout << "Entrez le nombre de processus qui doivent se donner rendezvous ! " << endl;
	cin >> nbrdv;

	opv.sem_num=0;
	opv.sem_op=1;
	opv.sem_flg=0;

	cle = ftok("docufile",8);
	f_id = semget(cle,1,IPC_CREAT|IPC_EXCL|0666);
	if ( f_id == -1) {
		f_id = semget(cle,1,0666);
		semctl(f_id,0,IPC_RMID);
		perror("erreur creation");}

	cout << "f_id =" << f_id << endl;
	arg_ctrl.val=nbrdv-1;
	if (semctl(f_id,0,SETVAL,arg_ctrl) ==  -1) {cout << "erreur init " << endl;}

	semop(f_id,&opv,1);

	unsigned short array2[1];
	semctl(f_id,0,GETALL,&array2);
	cout << "Nb places initial :" << array2[0] << endl;
	return 0;
}