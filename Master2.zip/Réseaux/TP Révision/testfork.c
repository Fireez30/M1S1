#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc,char** argv){
	if (argc!=2) {printf("Nb arguments invalides ! "); return -1;}
	int nbproc=atoi(argv[1]);

	for(int i=0;i<nbproc;i++){
		int x=fork();
		if (x==0){printf("PID :%d\n",getpid());printf("parent ID :%d\n",getppid());sleep(10);exit(1);}
	}
	while(wait(0) != -1){}
	return 0;
}