#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/wait.h>

void forkvert(int profondeur,char* message){
	if (profondeur==1) {exit(1);}
	int pipe1[2];
	pipe(pipe1);
	write(pipe1[1],message, strlen(message));
	int x=fork();
	if (x==0){
	printf("PID :%d\n",getpid());
	printf("parent ID :%d\n",getppid());
	if (profondeur>1){forkvert(profondeur-1,message);}
	}
	int y=fork();
	if (y==0){
	pipe(pipe1);
	printf("PID :%d\n",getpid());
	printf("parent ID :%d\n",getppid());
	if (profondeur>0){forkvert(profondeur-1,message);}

	}
	while(wait(0) != -1){}
	char buffer[BUFSIZ+1];
	read(pipe1[0],buffer,BUFSIZ);
	printf("%s\n",buffer);
}

int main(int argc,char** argv){
	if (argc!=2) {printf("Nb arguments invalides ! "); return -1;}
	int nbproc=atoi(argv[1]);
	char message[100];
	message[99]="\0";
	printf("Messsage : \n");
	scanf("%s",&message);
	forkvert(nbproc,message);
	return 0;
}