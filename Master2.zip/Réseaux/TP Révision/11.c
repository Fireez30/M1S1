#include <stdlib.h>
#include <stdio.h>

int main(){
	int a=10;
	int b=25;
	int * p = &b;//pointeur sur b
	int * pp = &a;//pointeur sur a

	printf("Valeur de l'expression : %d\n",*(&(*(*(&p)))-1));
	printf("Valeur de a : %d\n",a);
	printf("Valeur de b : %d\n",b);
	printf("Adresse de a : %d\n",&a);
	printf("Adresse de b : %d\n",&b);
	printf("Valeur de p : %d\n",p);
	printf("Valeur de pp : %d",pp);
	return 0;
}