#include <stdlib.h>
#include <stdio.h>

int sommetab(int * t,int taille){
if (taille==1){return t[taille];}
	else {return (t[taille-1]+sommetab(t,taille-1));}
}

int main(){
	int taille;
	printf("Nombre d'éléments du tableau :\n");
	scanf("%d", &taille);
	int tab[taille];
	int elemtempo;
	printf("Entre les éléments :\n");
	for (int i=0;i<taille;i++){
		scanf("%d",&elemtempo);
		tab[i]=elemtempo;
	}

	printf("%d",sommetab(tab,taille));
	return 0;


}