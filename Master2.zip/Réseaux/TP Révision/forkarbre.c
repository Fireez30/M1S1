#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void forkvert(int profondeur){
	if (profondeur==1) {exit(1);}
	int x=fork();
	if (x==0){printf("PID :%d\n",getpid());
	printf("parent ID :%d\n",getppid());
	if (profondeur>1){forkvert(profondeur-1);}
	}
	int y=fork();
	if (y==0){printf("PID :%d\n",getpid());
	printf("parent ID :%d\n",getppid());
	if (profondeur>0){forkvert(profondeur-1);}
	}
	sleep(20);
	while(wait(0) != -1){}
}
int main(int argc,char** argv){
	if (argc!=2) {printf("Nb arguments invalides ! "); return -1;}
	int nbproc=atoi(argv[1]);

forkvert(nbproc);
	return 0;
}