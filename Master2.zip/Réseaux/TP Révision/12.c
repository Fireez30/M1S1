#include <stdlib.h>
#include <stdio.h>

int* extract(int * t,int taille,int b1, int b2){
	int res[taille];
	for(int i=0;i<taille;i++){
		if(t[i]>=b1 && t[i]<=b2){res[i]=t[i];}
	}
	return &res;
}
int main(){
	int taille;
	printf("Nombre d'éléments du tableau :\n");
	scanf("%d", &taille);
	int tab[taille];
	int elemtempo;
	printf("Entre les éléments :\n");
	for (int i=0;i<taille;i++){
		scanf("%d",&elemtempo);
		tab[i]=elemtempo;
	}

	int * t=extract(&tab,taille,3,8);
	printf("test");
	for(int i=0;i<taille;i++){printf("%d",t[i]);}
	return 0;


}