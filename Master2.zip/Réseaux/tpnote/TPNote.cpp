#include <iostream>
#include <cstdlib>
#include <pthread.h>
#include <thread>
#include <time.h>
#include <unistd.h>


using namespace std;

typedef struct s_n_verrou{
	int nbthreadsmax;
	pthread_mutex_t *tab;
} n_verrou;


int n_verrou_init(n_verrou * v,int k){//initialisation des verrous
	v->nbthreadsmax=k;//nb max de verrou en simultanés
	pthread_mutex_t verr[k];
	for (int i=0;i<k;i++){verr[i]=PTHREAD_MUTEX_INITIALIZER;}
        v->tab = verr;
    cout << "init fait " << endl;
    return 0;
}

int n_verrou_lock(n_verrou * v){//fonction d'entrée dans la section critique
	for (int i=0; i < v->nbthreadsmax ; i++){
		if (pthread_mutex_lock(&v->tab[i]) != 0){break;}//Si le verrou est occupé avancer au suivant
		if (i == v->nbthreadsmax - 1 ) {return -1;}//Si on est au dernier verrou alors rien n'est libre
	}
	return 0;
}

int n_verrou_unlock(n_verrou * v){//fonction sortie de section critique
	for (int i=0; i < v->nbthreadsmax; i++) {//unlock de tous les verrous
		pthread_mutex_unlock(&v->tab[i]);
	}
	return 0;
}

int n_verrou_destroy(n_verrou * v){//destructeur
	free(v);
}


void * traitement1(void * param){//traitement 1 
	cout << "traitement 1 ! " << endl;
	sleep(2);
}

void * traitement2(void * param){
		n_verrou_lock(((n_verrou *)param));//lancer un lock pour se bloquer a un nombre de thread simulatnés max
		cout << "Traitement de 2 ! " << endl;
		sleep(2);
		n_verrou_unlock(((n_verrou *)param));//apres traitement unlock 
}

void * traitement3(void * param){//traitement 3
	cout << "traitement 3 ! " << endl;
		sleep(3);
}

void * traitementprincipal(void * param){//le traitement principal gère la sequence de 3 traitements
	traitement1(NULL);
	traitement2(NULL);
	traitement3(NULL);
}


int main(){
int nbthreads=0;//nb de threads 
int max=0;//nb threads simultanés max

cout << "Veuillez saisir le nombre de threads à éxecuter " << endl;
cin >> nbthreads;
cout << "Veuillez saisir le nombre max de threads en simultané sur la séquence de traitement 2 : " << endl;
cin >> max;

pthread_t t[nbthreads];//tableau de threads
n_verrou nv;
n_verrou_init(&nv,max);

for(int i=0; i < nbthreads; i++){//lancement du traitement de chaque thread
	  if (pthread_create(&t[i], NULL,traitementprincipal,&nv) != 0){cout << "Erreur lors de la création du thread : " << i  << endl;}
}


for (int i=0; i < nbthreads; i++){//Attente de la fin de l'ensemble des threads 
	pthread_join(t[i], NULL);
}
	return 0;


}