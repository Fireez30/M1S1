#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

typedef struct
{
	sem_t* semaphore; // semaphore
	int k;            // max number of threads
} n_verrou;

int n_verrou_init(n_verrou* v, int k);
int n_verrou_lock(n_verrou* v);
int n_verrou_unlock(n_verrou* v);
int n_verrou_destroy(n_verrou* v);

// "traitement" functions, called by the main thread function
void traitement1(int tid, int nthreads);
void traitement2(int tid, int nthreads);
void traitement3(int tid, int nthreads);

// data used by every thread
typedef struct
{
	n_verrou lock; // lock for traitement2
	int id;        // thread number
	int nthreads;  // total number of threads
} thread_data;

// thread function (uses traitement1-3)
void* threadfn(void* data);

int main(int argc, char** argv)
{
	if(argc != 3)
	{
		fprintf(stderr, "(ಠ_ಠ) Wrong number of arguments for this program.\n"\
		"Here's how to use it properly:\n"\
		"\t%s [nthreads] [maxthreads]\n"\
		"Where [nthreads] is the total number of threads and [maxthreads] is\n"\
		"the maximum number of threads allowed in traitement2.\n", argv[0]);

		return EXIT_FAILURE;
	}

	// read parameters
	int nthreads = atoi(argv[1]);
	int maxthreads = atoi(argv[2]);
	if(maxthreads > nthreads)
	{
		fprintf(stderr, "(ಠ_ಠ) maxthreads must not be greater than nthreads.\n");
		return EXIT_FAILURE;
	}

	// create n threads
	pthread_t* threads = (pthread_t*) malloc(nthreads * sizeof(pthread_t));
	if(threads == NULL)
	{
		fprintf(stderr, "(;_;) Couldn't allocate %ld bytes for the threads.\n",
				nthreads * sizeof(pthread_t));
		return EXIT_FAILURE;
	}

	// create the lock:
	n_verrou lock;
	if(n_verrou_init(&lock, maxthreads) == -1)
	{
		fprintf(stderr, "(O_O) Couldn't initialize n_verrou.\n");
		return EXIT_FAILURE;
	}

	// initialize threads
	int i;
	for(i = 0; i < nthreads; ++i)
	{
		// create the thread data
		// (the data is freed in the thread function)
		thread_data* data = (thread_data*) malloc(sizeof(thread_data));
		data->lock = lock;
		data->id = i;
		data->nthreads = nthreads;

		// initialize thread
		if(pthread_create(&threads[i], NULL, threadfn, (void*) data) != 0)
		{
			fprintf(stderr, "(T_T) Couldn't create thread %d.\n", i);
			return EXIT_FAILURE;
		}
	}

	// wait for all threads to finish
	for(i = 0; i < nthreads; ++i)
	{
		if(pthread_join(threads[i], NULL) != 0)
		{
			fprintf(stderr, "D: Couldn't join thread %d.\n", i);
			return EXIT_FAILURE;
		}
	}

	// free data
	free(threads);
	if(n_verrou_destroy(&lock) == -1)
	{
		fprintf(stderr, "(._.) Couldn't destroy n_verrou.\n");
		return EXIT_FAILURE;
	}

	return EXIT_SUCCESS;
}

void* threadfn(void* data)
{
	int tid       = ( (thread_data*) data )->id;
	n_verrou lock = ( (thread_data*) data )->lock;
	int nthreads  = ( (thread_data*) data )->nthreads;
	free(data);

	traitement1(tid, nthreads);

	if(n_verrou_lock(&lock) == -1)
	{
		fprintf(stderr, ":,( Couldn't lock n_verrou for thread %d.\n", tid);
		exit(EXIT_FAILURE);
	}

	traitement2(tid, nthreads);

	if(n_verrou_unlock(&lock) == -1)
	{
		fprintf(stderr, "(-_-) Couldn't unlock n_verrou for thread %d.\n", tid);
		exit(EXIT_FAILURE);
	}

	traitement3(tid, nthreads);

	pthread_exit(NULL);
}

// prints the traitement opening or closing on the thread's column
void traitement_print(int open, int traitement, int tid, int nthreads)
{
	char bracket = open ? '{' : '}';

	int i;
	for(i = 0; i < tid; ++i)
		printf("|\t");

	printf("%c T%d\t", bracket, traitement);

	for(i = tid+1; i < nthreads; ++i)
		printf("|\t");

	printf("\n");
}

void traitement1(int tid, int nthreads)
{
	traitement_print(1, 1, tid, nthreads);
	sleep(1);
	traitement_print(0, 1, tid, nthreads);
}

void traitement2(int tid, int nthreads)
{
	traitement_print(1, 2, tid, nthreads);
	sleep(2);
	traitement_print(0, 2, tid, nthreads);
}

void traitement3(int tid, int nthreads)
{
	traitement_print(1, 3, tid, nthreads);
	sleep(5);
	traitement_print(0, 3, tid, nthreads);
}

int n_verrou_init(n_verrou* v, int k)
{
	v->k = k;

	sem_t* semaphore = (sem_t*) malloc(sizeof(sem_t));
	if(semaphore == NULL)
		return -1;

	v->semaphore = semaphore;

	return sem_init(v->semaphore, 0, k);
}

int n_verrou_lock(n_verrou* v)
{
	return sem_wait(v->semaphore);
}

int n_verrou_unlock(n_verrou* v)
{
	return sem_post(v->semaphore);
}

int n_verrou_destroy(n_verrou* v)
{
	if(sem_destroy(v->semaphore) == -1)
		return -1;

	free(v->semaphore);
	return 0;
}
