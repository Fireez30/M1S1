#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct n_verrou
{
	int k;
	pthread_mutex_t verrou;
	pthread_cond_t condition;
	int nbrthreadt2;
}n_verrou;

int n_verrou_init(n_verrou* v, int k)
{
	v->k = k;

	v->nbrthreadt2=0;

	if(!pthread_mutex_init(&v->verrou,NULL)) 
	{
		return -1;
	}

  	if(!pthread_cond_init(&v->condition,NULL)) 
  	{
  		return -1;
  	}

	return 0;
}



int n_mutex_destroy(n_verrou *v)
{
  free(v);

  return 0;
}

int n_verrou_lock(n_verrou* v)
{
	pthread_mutex_lock(&(v->verrou));
	pthread_t moi=pthread_self();

	if(v->nbrthreadt2 <= v->k)
	{
		v->nbrthreadt2++;
		int placedispo = v->k - v->nbrthreadt2;
		printf("Il y a assez de place pour le thread %d, je fais le traitement 2 et il reste %d places\n",(int)moi, placedispo);
		pthread_mutex_unlock(&(v->verrou));

	}
	else
	{
		printf("il n'y a plus de place, j'attend\n");
		pthread_cond_wait(&(v->condition), &(v->verrou));
		pthread_exit(NULL);
	}

	return 0;
}

int n_verrou_unlock(struct n_verrou *v)
{
  pthread_t moi= pthread_self();
  printf("le unlock a été lancer\n");
  pthread_mutex_lock(&(v->verrou));

  if(v->nbrthreadt2==0)
  {
    pthread_mutex_unlock(&v->verrou);
    printf("Aucun thread à libérer\n");

    return -1;
  }

  else
  {
    v->nbrthreadt2--;
    int placedispo = v->k - v->nbrthreadt2;
    printf("Je libére le thread %d il reste %d places\n",(int)moi,placedispo);
    pthread_mutex_unlock(&v->verrou);
    pthread_cond_broadcast(&(v->condition));
    return 0;
  }
}


void* seqtraitement(void* par)
{
	struct n_verrou* mastruct = (struct n_verrou*)par;
	pthread_t moi= pthread_self();
	printf("Je suis %d et j'effectue le traitement numero 1 \n Je termine ce traitement, j'essaie le 2 \n", (int)moi);
	n_verrou_lock(mastruct);
	n_verrou_unlock(mastruct);

	printf("je suis %d et j'effectue le dernier traitement\n J'ai fini\n", (int)moi);
	pthread_exit(NULL);
}

int main()
{
	struct n_verrou* mastruct;
	mastruct = malloc(sizeof(struct n_verrou));
	int tmax=0, nbt=0;
	n_verrou_init(mastruct, tmax);

	printf("Entrez le nombre de thread souhaité\n");
	scanf("%d",&nbt);
	printf("Entrez le nombre maximum de thread pouvant être en situation critique \n");
	scanf("%d",&tmax);

	pthread_t* threads = malloc(nbt*sizeof(pthread_t));
	
	for(int i=0;i<nbt;i++)
	{
		if(pthread_create(&(threads[i]), NULL, seqtraitement, (void*)mastruct));
		{
			perror("Erreur lors de la création des threads");
			return EXIT_FAILURE;
		}

	}

	for(int i=0;i<nbt;i++)
	{
		pthread_join(threads[i],NULL);
	}

	n_mutex_destroy(mastruct);
	return EXIT_SUCCESS;
}