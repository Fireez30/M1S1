#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define NTOTALTHREADS 20
#define NMAXTHREADS 3

/*
 * Structure of synchronization for limit
 * the max processing threads of a function.
 */
typedef struct n_verrou_tag {
  int threads;              /* Number of threads allowed to run a function */
  pthread_mutex_t mutex;    /* Mutex to protect threads number */
  pthread_cond_t cond;      /* Condition variable to notify the threads number */
} n_verrou_t;

int n_verrou_init(n_verrou_t* v, int k);

int n_verrou_lock(n_verrou_t* v);

int n_verrou_unlock(n_verrou_t* v);

int n_verrou_destroy(n_verrou_t* v);

void* traitement1(void* arg);
void* traitement2(void* arg);
void* traitement3(void* arg);


n_verrou_t lock;

int main(int argc, char** argv)
{
  int done = 0;
  int thread_index = 0;
  pthread_t threads[NTOTALTHREADS];
  n_verrou_init(&lock, NMAXTHREADS);

  while (!done) {
    if (thread_index >= NTOTALTHREADS)
      done = 1;

    n_verrou_lock(&lock);

    while (lock.threads >= 3) {
      pthread_cond_wait(&lock.cond, &lock.mutex);
    }

    pthread_create(&threads[thread_index++], NULL, traitement2, NULL);

    n_verrou_unlock(&lock);

    pthread_create(&threads[thread_index++], NULL, traitement1, NULL);
    //sleep(2);
    pthread_create(&threads[thread_index++], NULL, traitement3, NULL);
    //sleep(2);
  }

  for (int i = 0; i < NTOTALTHREADS; ++i) {
    pthread_join(threads[i], NULL);
  }

  n_verrou_destroy(&lock);

  return 0;
}


int n_verrou_init(n_verrou_t* v, int k)
{
  int status;

  status = pthread_mutex_init(&v->mutex, NULL);
  if (status != 0)
    return -1;

  status = pthread_cond_init(&v->cond, NULL);
  if (status != 0)
    return -1;

  return 0;
}

int n_verrou_lock(n_verrou_t* v)
{
  int status;

  status = pthread_mutex_lock(&v->mutex);
  if (status != 0)
    return -1;

  return 0;
}

int n_verrou_unlock(n_verrou_t* v)
{

  int status;

  status = pthread_mutex_unlock(&v->mutex);
  if (status != 0)
    return -1;

  return 0;
}

int n_verrou_destroy(n_verrou_t* v)
{
  int status;

  status = pthread_mutex_destroy(&v->mutex);
  if (status != 0)
    return -1;

  status = pthread_cond_destroy(&v->cond);
  if (status != 0)
    return -1;
}

void* traitement1(void* arg)
{
  printf("Thread [%u] is doing traitement 1 ...\n", (unsigned int)pthread_self());
  sleep(2);
  printf("Thread [%u] finish traitement 1 ...\n", (unsigned int)pthread_self());
}

void* traitement2(void* arg)
{
  n_verrou_lock(&lock);

  lock.threads += 1;

  printf("Thread [%u] is doing traitement 2 ...\n", (unsigned int)pthread_self());
  printf("Number of threads on the <traitement2> : %d\n", lock.threads);
  //for (int i = 0; i < 10000000; ++i);
  sleep(4);
  printf("Thread [%u] finish traitement 2 ...\n", (unsigned int)pthread_self());

  lock.threads -= 1;

  if (lock.threads < NMAXTHREADS)
    pthread_cond_broadcast(&lock.cond);

  n_verrou_unlock(&lock);
}

void* traitement3(void* arg)
{
  printf("Thread [%u] is doing traitement 3 ...\n", (unsigned int)pthread_self());
  //for (int i = 0; i < 1000000000; ++i);
  sleep(8);
  printf("Thread [%u] finish traitement 3 ...\n", (unsigned int)pthread_self());
}