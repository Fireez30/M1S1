#include <iostream>
#include <cstdlib>
#include <pthread.h>
#include <thread>
#include <time.h>

using namespace std;

pthread_mutex_t Verrou = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t Condition = PTHREAD_COND_INITIALIZER;
unsigned somme = 0;

unsigned somme2 = 0;

typedef struct s_vecteur {
    int v1;
    int v2;
} vecteur;

typedef struct s_sum {
    int * all;
    int size;
} sum;

typedef struct s_sync {
    int ID;
    int size;
} sync;

typedef struct s_thrWithID {
    unsigned ID;
    unsigned size;
    pthread_mutex_t *verroux;
} thrWithID;



void * DisplayLoop (void * p){
    pthread_t moi = pthread_self();
    for (unsigned i (0); i < 10; ++i)
        cout << "thread " << moi << " : " << i << endl;

    pthread_exit(NULL);
}

void * DisplayChar (void * p) {
    pthread_t moi = pthread_self();
    cout << "thread " << moi << " : " << (char *) p << endl;
}

void question1 () {
   pthread_t t1, t2;//2 threads

   if (pthread_create(&t1, NULL, DisplayLoop, NULL) != 0) cout << "creation error !" << endl;//lancement thread 1 qui affiche de 0 a 10

   if (pthread_create(&t2, NULL, DisplayLoop, NULL) != 0) cout << "creation error !" << endl;//lancement thread 2

   pthread_join(t1, NULL);//fin du thread 1
   pthread_join(t2, NULL);//fin du thread 2 
}

void question4 () {
    char a = 'a';

    pthread_t t1, t2;

    if (pthread_create(&t1, NULL, DisplayChar, &g) != 0) cout << "creation error !" << endl;//lancement thread avec parametre

    if (pthread_create(&t2, NULL, DisplayChar, &g) != 0) cout << "creation error !" << endl;//lancement thread 2 avec parametre

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);//attente de la fin 
}

void * addition (void * p){

    int * res = (int *) malloc(sizeof(int));//resultat
    *res = 0;

    pthread_mutex_lock(&Verrou);//verrou attente multiplication

    for (unsigned i (0); i < ((sum *)p)->size; i++)
        *res += ((sum *)p)->all[i];//addition des résultat des multiplication

    pthread_mutex_unlock(&Verrou);//travail terminé

    pthread_exit(res);

}

void * multiplication (void * p){

    int * res = (int *) malloc(sizeof(int));

    *res = ((vecteur*)p)->v1 * ((vecteur*)p)->v2;

    cout << *res << endl;

    pthread_exit(res);

}

void exo2(unsigned n){

    vecteur v[n];//tableau des vecteurs a multiplier
    sum res;//structure contenant le résultat des multiplications

    res.size = n;//taille de la struct

    pthread_t mult [n], add;//creation des threads de multiplication et celui d'addition
    unsigned sum = 0;
    int * ptr;

    for (unsigned i (0); i < n; ++i) {
        v[i].v1 = rand() % 11;
        v[i].v2 = rand() % 11;
    }//remplissage des vecteurs

    pthread_mutex_lock(&Verrou);//lock du verrou qui indique que les multiplications sont finies

    for (unsigned i (0); i < n; ++i) {
        if (pthread_create(&mult[i], NULL, multiplication, &v[i]) != 0) cout << "creation error !" << endl;
    }//lancement des threads de multiplication avec le vecteur lui correspondant en param

    if (pthread_create(&add, NULL, addition, &res) != 0) cout << "creation error !" << endl;//lancement du thread d'addition

    for (unsigned i (0); i < n; ++i) {
        pthread_join(mult[i], (void **) &ptr);
        res.all[i] = *ptr;
    }//attente et stockage des résultat des threads de mult

    pthread_mutex_unlock(&Verrou);//verrou dispo lancement du thread d'addition

    pthread_join(add, (void **) &ptr);
    Sum = *ptr;//attente de la fin de l'addition et récupération du résultat

    cout << "Sum : " << Sum << endl;
}

void * multetadd (void * p){

    int * res = (int *) malloc(sizeof(int));

    *res = ((vecteur*)p)->v1 * ((vecteur*)p)->v2;//multiplication de son vecteur

    pthread_mutex_lock(&Verrou);//demande acces a la variable partagées somme2 (variable globale)

    cout << "adding " << *res << " to sum" << endl;
    somme2 += *res;

    pthread_mutex_unlock(&Verrou);//fin du travail sur somme 2
}

void exercice2(unsigned n){
    vecteur v[n];//vecteurs
    pthread_t mult [n];//threads multiplication et addition

    for (unsigned i (0); i < n; ++i) {
        v[i].v1 = rand() % 10 + 1;
        v[i].v2 = rand() % 10 + 1;
    }//remplissage des vecteurs

    for (unsigned i (0); i < n; ++i) {
        if (pthread_create(&mult[i], NULL, multetadd, &v[i]) != 0) cout << "creation error !" << endl;
    }//creation des threads de mult et add

    for (unsigned i (0); i < n; ++i) {
        pthread_join(mult[i],NULL);
    }//attente de la fin 

    cout << "Sum : " << somme2 << endl;
}

unsigned TachePred;

void * task(void * p){

    pthread_mutex_unlock(&((thrWithID*)p)->verroux[((thrWithID*)p)->ID]);

    cout << "thread " << ((thrWithID*)p)->ID << " : Lock " << ((thrWithID*)p)->ID << " is locked" << endl;
    pthread_mutex_lock(&((thrWithID*)p)->verroux[((thrWithID*)p)->ID]);


    cout << "thread " << ((thrWithID*)p)->ID << " : computing" << endl;

    unsigned Calc = 0;

    while (Calc++ != 10000000){}

    pthread_mutex_unlock(&((thrWithID*)p)->verroux[((thrWithID*)p)->ID]);
    cout << "thread " << ((thrWithID*)p)->ID << " : Lock " << ((thrWithID*)p)->ID << " is unlocked" << endl;

    cout << "thread " << ((thrWithID*)p)->ID << " : waiting for other thread" << endl;

    for (unsigned i (0); i < ((thrWithID*)p)->size ; ++i)
        if (i != ((thrWithID*)p)->ID){
            cout << "thread " << ((thrWithID*)p)->ID << " : Lock " << i << " is locked" << endl;
            pthread_mutex_lock(&((thrWithID*)p)->verroux[i]);
            pthread_mutex_unlock(&((thrWithID*)p)->verroux[i]);
            cout << "thread " << ((thrWithID*)p)->ID << " : Lock " << i << " is unlocked" << endl;
        }


    cout << "thread " << ((thrWithID*)p)->ID << " : wait ended" << endl;
}

void exercice3 (unsigned n){
    thrWithID threads[n];
    pthread_t tache[n];
    pthread_mutex_t verroux[n];

    for (unsigned i (0); i < n; ++i){
        verroux[n] = PTHREAD_MUTEX_INITIALIZER;
    }

    for (unsigned i (0); i < n; ++i){
        threads[i].ID = i;
        threads[i].size = n;
        threads[i].verroux = verroux;
    }


    for (unsigned i (0); i < n; ++i)
        if (pthread_create(&tache[i], NULL, task, &threads[i]) != 0)
            cout << "creation error !" << endl;

    for (unsigned i (0); i < n ; ++i)
        pthread_join(tache[i], NULL);

}

void * taskcond(void * p){

    cout << "thread " << ((sync*)p)->ID << " : start" << endl;

    unsigned Calc = 0;

    while (Calc++ != 10){cout << "thread " << ((sync*)p)->ID << " : Computing at " << Calc << endl; }

    pthread_mutex_lock(&Verrou);
    somme++;
    while (somme < ((sync*)p)->size){
        pthread_cond_wait(&Condition, &Verrou);
        cout << "thread " << ((sync*)p)->ID << " : wait" << endl;
    }

    cout << "thread " << ((sync*)p)->ID << " : wait ended" << endl;

    pthread_mutex_unlock(&Verrou);

    pthread_cond_broadcast(&Condition);
}

void exercice3withcond (unsigned n){

    pthread_t threads [n];

    sync Number[n];

    for (unsigned i (0); i < n; ++i){
        Number[i].ID = i;
        Number[i].size = n;
        if (pthread_create(&threads[i], NULL, taskcond, &Number[i]) != 0)
            cout << "creation error !" << endl;
    }

    for (unsigned i (0); i < n ; ++i)
        pthread_join(threads[i], NULL);

}

int * dCommun;

void * travailthread (void * p) {

    cout << "thread " << ((sync*)p)->ID << " : start" << endl;

    for (unsigned i (0); i < ((sync *)p)->size; ++i) {

        unsigned Calc = 0;

        pthread_mutex_lock(&Verrou);
        if (((sync*)p)->ID != ((sync*)p)->size - 1) {
            while (dCommun[((sync*)p)->ID + 1] <= i) {
                pthread_mutex_unlock(&Verrou);
                pthread_mutex_lock(&Verrou);
            }

            dCommun[((sync*)p)->ID] = i;

            pthread_mutex_unlock(&Verrou);

            while (Calc++ != 10){cout << "thread " << ((sync*)p)->ID << " : Working on " << i << endl; }
            continue;
        }
        dCommun[((sync*)p)->ID] = i;

        pthread_mutex_unlock(&Verrou);

        while (Calc++ != 10){cout << "thread " << ((sync*)p)->ID << " : Working on " << i << endl; }
    }

    dCommun[((sync*)p)->ID] = ((sync*)p)->size;

}

void exercice4(unsigned n) {
     pthread_t threads [n];

     dCommun = (int *) malloc(sizeof(int) * n);

     sync Number[n];

     for (unsigned i (0); i < n; ++i){
         dCommun[i] = -1;
     }

     for (unsigned i (0); i < n; ++i){
         Number[i].ID = i;
         Number[i].size = n;
         if (pthread_create(&threads[i], NULL, travailthread, &Number[i]) != 0)
             cout << "creation error !" << endl;
     }

     for (unsigned i (0); i < n ; ++i)
         pthread_join(threads[i], NULL);

}


void * travail (void * p) {

    cout << "thread " << ((sync*)p)->ID << " : start" << endl;

    for (int i (0); i < ((sync *)p)->size; ++i) {

        unsigned Calc = 0;
        unsigned Random = rand() % 10000000000;

        pthread_mutex_lock(&Verrou);
        if (((sync*)p)->ID != ((sync*)p)->size - 1) {
            for (int j (((sync*)p)->ID + 1) ; j < ((sync*)p)->size; ++j){
                while (dCommun[j] <= i) {
                    cout << "thread " << ((sync*)p)->ID << " : waiting for zone " << i << endl;
                    pthread_cond_wait(&Condition, &Verrou);
                }
            }//Attente que tous les threads aient finis

            cout << "thread " << ((sync*)p)->ID << " : wait ended" << endl;

            //cout << "thread " << ((sync*)p)->ID << " : start working on zone "  << i << endl;

            //cout << "from thread " << ((sync*)p)->ID << " next thread is in zone " << dCommun[((sync*)p)->ID + 1] << endl;


            dCommun[((sync*)p)->ID] = i;

            pthread_mutex_unlock(&Verrou);
            pthread_cond_broadcast(&Condition);

            cout << "thread " << ((sync*)p)->ID << " : WAKE UP EVERYONE !!!!" << endl;


            cout << "thread " << ((sync*)p)->ID << " : Working on zone " << i << endl;
            while (Calc++ != Random){if (Calc % 1000000000 == 0)  cout << "thread " << ((sync*)p)->ID << " : Working on zone " << i << "(" << Calc << ")" << endl;}
            cout << "thread " << ((sync*)p)->ID << " : Work ended on zone " << i << endl;


            continue;
        }

         dCommun[((sync*)p)->ID] = i;

        pthread_mutex_unlock(&Verrou);
        pthread_cond_broadcast(&Condition);

        cout << "thread " << ((sync*)p)->ID << " : WAKE UP EVERYONE !!!!" << endl;

        cout << "thread " << ((sync*)p)->ID << " : Working on zone " << i << endl;
        while (Calc++ != Random){if (Calc % 1000000000 == 0)  cout << "thread " << ((sync*)p)->ID << " : Working on zone " << i << "(" << Calc << ")" << endl;}


        cout << "thread " << ((sync*)p)->ID << " : Work ended on zone " << i << endl;





    }


    dCommun[((sync*)p)->ID] = ((sync*)p)->size;

    pthread_cond_signal(&Condition);

}

void exercice4withcond (unsigned n) {
     pthread_t threads [n];//tablo de threads

     dCommun = (int *) malloc(sizeof(int) * n);//tableau de données communes

     sync Number[n];//un tableau  ID dun thread + nb threads

      dCommun[n-1] = 0;

     for (unsigned i (0); i < n - 1; ++i){
         dCommun[i] = -1;
     }//initialisation des données communes

     for (unsigned i (0); i < n; ++i){
         Number[i].ID = i;
         Number[i].size = n;
         if (pthread_create(&threads[i], NULL, travail, &Number[i]) != 0)
             cout << "creation error !" << endl;
     }

     for (unsigned i (0); i < n ; ++i)
         pthread_join(threads[i], NULL);

}

int main(){
    srand(time(NULL));
    int n;
    /*cout << "EXO 1" << endl;
    cout << "Question 1 :  " << endl;
    Question1();
    cout << "Question 2 : Les threads ne s'executeront pas" << endl;
    cout << "Question 3 : Le programme entier s'arrete" << endl;
    cout << "Question 4 : " << endl;
    Question4();
    cout << "EXO 2" << endl;
    cout << "Question 3 :  " << endl;*/
    cout << "Entrez le nombre de taches : ";

    cin >> n;

    cout << "Execution de l'exo 4 : "
    exercice4withcond(n);




    return 0;
}