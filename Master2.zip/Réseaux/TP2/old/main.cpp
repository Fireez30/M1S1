
#include <iostream>
#include <thread>
#include <time.h>

using namespace std;

pthread_mutex_t verrou2 = PTHREAD_MUTEX_INITIALIZER;
typedef struct s_xyzzy {
    int x;
    int y;
} structs;

typedef struct s_sum {
	int * all;
	int size;
} sum;

void * ta1(void * p){
    pthread_t moi=pthread_self();
    for(int i=0;i<10;i++){cout << "Boucle : "<<i<< "Thread :" << moi << endl;}
    exit(0);
}

void * ta2(void * p){
	cout << "P : " << (char *) p << endl;
}

void * les(void * p){

int * res=(int *) malloc(sizeof(int));
	*res=((structs * )p)->x * ((structs * )p)->y;
	pthread_exit(res);
}


void * sumtab(void * p){
int * res= (int *) malloc(sizeof(int));
*res = 0;

pthread_mutex_lock(&verrou2);
for(int i=0;i<((sum *)p)->size;i++){*res += ((sum *)p)->all[i];}
pthread_mutex_unlock(&verrou2);
pthread_exit(res);
}

int main()
{
//Question1
/*
   pthread_t t1,t2;

   if (pthread_create(&t1,NULL,ta1,NULL) != 0) {cout << "error" << endl;}
   if (pthread_create(&t2,NULL,ta1,NULL) != 0) {cout << "error" << endl;}

   pthread_join(t1,NULL);
   pthread_join(t2,NULL);
*/

/*Question 2
 Il se passe rien */

/*Question 3
Tout se ferme
*/

// Question 4

/*
	pthread_t t1,t2;

char g = 'p';


   if (pthread_create(&t1,NULL,ta2,&g) != 0) {cout << "error" << endl;}
   if (pthread_create(&t2,NULL,ta2,&g) != 0) {cout << "error" << endl;}

   pthread_join(t1,NULL);
   pthread_join(t2,NULL);
*/

//Question 5


/*
	int n;
	
	int counter=0;
	structs a;
	srand(time(NULL));
	cout << "Dimension des vecteurs :"  << endl;
	cin >> n;
	pthread_t t[n];
	pthread_t t1;
	int v1[n];
	int v2[n];
	for(int i=0;i<n;i++){
		v1[i]=rand() % 100;
		v2[i]=rand() % 100;
	}
	int * res;
	int resultat[n];

	for(int i=0;i<n;i++){a.x=v1[i];a.y=v2[i];pthread_create(&t[i],NULL,les,&a);}
	for(int i=0;i<n;i++){pthread_join(t[i],(void **) &res);resultat[i]=*res;}

	pthread_create(&t1,NULL,sumtab,&resultat)
	//for(int i=0;i<n;i++){counter+=resultat[i];}

	cout << "Total = " << counter << endl;
*/

//Question 6 
/*
		int n;
	int * ptr;

	int counter=0;
	structs a;
	srand(time(NULL));
	cout << "Dimension des vecteurs :"  << endl;
	cin >> n;
	pthread_t t[n];
	pthread_t t1;
	int v1[n];
	int v2[n];
	for(int i=0;i<n;i++){
		v1[i]=rand() % 100;
		v2[i]=rand() % 100;
	}
	int * res;
	int resultat[n];
	pthread_mutex_lock(&verrou2);
	for(int i=0;i<n;i++){a.x=v1[i];a.y=v2[i];pthread_create(&t[i],NULL,les,&a);}

		if (pthread_create(&t1,NULL,sumtab,&res) != 0) cout << "Creation error !" << endl;
			for(int i=0;i<n;i++){pthread_join(t[i],(void **) &res);resultat[i]=*res;}

pthread_mutex_unlock(&verrou2);
pthread_join(t1,(void **) &ptr);
int Sum=*ptr;

cout << "Sum :" << Sum << endl;
	//for(int i=0;i<n;i++){counter+=resultat[i];}
*/


//Question 7

	
    return 0;
}

