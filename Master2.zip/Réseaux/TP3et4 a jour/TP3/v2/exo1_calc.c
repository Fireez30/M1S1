#include <pthread.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

typedef struct strMsg{
	long eti;
	int op[2];
	char calc;
} message;

int main(){
	key_t clef = ftok("./generateur.txt", 25);
	int file = msgget(clef, IPC_CREAT|0666);
	int resultat;
	
	
	//traitement
	while(1){
		message operation;
		if(msgrcv(file, (void *) &operation, sizeof(message),1,0) == -1){
		printf("erreur reception");
		}
		switch (operation.calc){
			case '+' :
				resultat = operation.op[0]+operation.op[1];
				//printf("operation : %d + %d = %d \n", operation.op[0],operation.op[1],resultat);
				operation.eti = 2;
				operation.op[0] = resultat;
				msgsnd(file, (void *) &operation, sizeof(message),0);
				break;
				case '-' :
				resultat = operation.op[0]-operation.op[1];
				//printf("operation : %d - %d = %d \n", operation.op[0],operation.op[1],resultat);
				operation.eti = 2;
				operation.op[0] = resultat;
				msgsnd(file, (void *) &operation, sizeof(message),0);
				break;
				case '*' :
				resultat = operation.op[0]*operation.op[1];
				//printf("operation : %d * %d = %d \n", operation.op[0],operation.op[1],resultat);
				operation.eti = 2;
				operation.op[0] = resultat;
				msgsnd(file, (void *) &operation, sizeof(message),0);
				break;
				case '/' :
				resultat = operation.op[0]/operation.op[1];
				//printf("operation : %d / %d = %d \n", operation.op[0],operation.op[1],resultat);
				operation.eti = 2;
				operation.op[0] = resultat;
				msgsnd(file, (void *) &operation, sizeof(message),0);
				break;
		}	
	}
	

}
