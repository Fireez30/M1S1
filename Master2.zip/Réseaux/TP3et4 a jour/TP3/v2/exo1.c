#include <pthread.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

typedef struct strMsg{
	long eti;
	int op[2];
	char calc;
} message;

int main(){
	//creation clef
	key_t clef = ftok("./generateur.txt", 25);
	//creation file message ou recup id si existe
	int file = msgget(clef, IPC_CREAT|0666);
	message operation;
	///traitement///////
	operation.op[0] = 64;
	operation.op[1] = 26;
	operation.calc = '+';
	//////////////////////
	//donne une etiquette au message
	operation.eti = 1;
	
	//envois du message
	int envoi = msgsnd(file, (void *) &operation, sizeof(message),0);
	
	while(1){
		if(msgrcv(file, (void *) &operation, sizeof(message),2,0) == -1){
		printf("erreur reception");
		}
		printf("resultat : %d \n",operation.op[0]);
	}

}
