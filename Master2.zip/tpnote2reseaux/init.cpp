#include <iostream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string>
#include <unistd.h>
#include <sys/sem.h>

using namespace std;



int main(int argc,char** argv){

	struct sembuf opv;

union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *__buf;
} arg_ctrl;//Struct de controle des valeurs des semaphores

	int nbplace = atoi(argv[1]);//Nb de places en parametres

	key_t cle;
	int f_id;

	opv.sem_num=0;
	opv.sem_op=1;
	opv.sem_flg=0;

	cle = ftok("basekey",1);//Recuperatop, de la cle

	f_id = semget(cle,3,IPC_CREAT|IPC_EXCL|0666);//tentative de creation du semaphore, si il existe on le ferme et on echoue
	if ( f_id == -1) {
		f_id = semget(cle,1,0666);
		semctl(f_id,0,IPC_RMID);
		perror("Erreur lors de la creation, tableau de semaphore supprimé");
		return -1;}

	cout << "f_id =" << f_id << endl;
	arg_ctrl.val=nbplace;

	if (semctl(f_id,0,SETVAL,arg_ctrl) ==  -1) {cout << "Erreur lors de l'initialisation du nombre de place du semaphore" << endl;}//met en place le nb de place du bus

	if (semctl(f_id,2,SETVAL,arg_ctrl) ==  -1) {cout << "Erreur lors de l'initialisation de la descente des passagers du semaphore" << endl;}//met en place le semaphore de controle de sortie

	arg_ctrl.val=1;
	if (semctl(f_id,1,SETVAL,arg_ctrl) ==  -1) {cout << "Erreur lors de l'initialisation du timer du semaphore" << endl;}//met en place le timer

	unsigned short array2[3];
	semctl(f_id,0,GETALL,&array2);//controle des valeurs pour verifier que tout aille bien
	cout << "Nb places initial :" << array2[0] << endl;
	cout << "Timer :" << array2[1] << endl;
	cout << "Nb places pour la descente :" << array2[2] << endl;
	return 0;

	}