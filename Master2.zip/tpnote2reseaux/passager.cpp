#include <iostream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string>
#include <unistd.h>
#include <sys/sem.h>

using namespace std;



int main(int argc,char** argv){

	key_t cle;
	int f_id;


	struct sembuf oprmv;
	struct sembuf oprmvs;
	struct sembuf opatt;

	cle = ftok("basekey",1);//recuperation de la cle

	f_id = semget(cle,3,0666); //tentative dacces au tab de semaphore
	if ( f_id == -1) {perror("Erreur lors de lacces au tableau de semaphore dans le bus"); return -1;}


	oprmv.sem_num=0;//toutes les operations necessaires au programme
	oprmv.sem_op=-1;
	oprmv.sem_flg=0;

	oprmvs.sem_num=2;
	oprmvs.sem_op=-1;
	oprmvs.sem_flg=0;

	opatt.sem_num=1;
	opatt.sem_op=0;
	opatt.sem_flg=0;


	if (semop(f_id,&oprmv,1) == -1) {perror("Erreur lors de la tentative dentree dans le bus !");}//tente d'entrer dans le bus si des places sont dispo
	cout << "Attente du depart et  du parcours du bus " << endl;
	if (semop(f_id,&opatt,1) == -1) {perror("Erreur lors de lattente de la sortie !");}//attente de la fin du tour du bus
	cout << "Je sors ! " << endl;
	if (semop(f_id,&oprmvs,1) == -1) {perror("Erreur lors de lattente de la sortie !");}//Sors du bus en laissant sa place

	return 0;

}