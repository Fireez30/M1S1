#include <iostream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string>
#include <unistd.h>
#include <sys/sem.h>

using namespace std;



int main(int argc,char** argv){

	key_t cle;
	int f_id;

	int nbplace=atoi(argv[1]);

	struct sembuf opatt;
	struct sembuf opatt2;
	struct sembuf oprem;
	struct sembuf opadd;
	struct sembuf opaddt1;
	struct sembuf opadde;

		union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *__buf;
} arg;

	
	cle = ftok("basekey",1);//recuperation de la cle

	f_id = semget(cle,3,0666); //tentative dacces au tableau de semaphore
	if ( f_id == -1) {perror("Erreur lors de lacces au tableau de semaphore dans le bus"); return -1;}


	opatt.sem_num=0;//toutes les operations qui seront effectuees
	opatt.sem_op=0;
	opatt.sem_flg=0;

	opatt2.sem_num=2;
	opatt2.sem_op=0;
	opatt2.sem_flg=0;

	oprem.sem_num=1;
	oprem.sem_op=-1;
	oprem.sem_flg=0;

	opadd.sem_num=2;
	opadd.sem_op=1;
	opadd.sem_flg=0;

	opadd.sem_num=0;
	opadd.sem_op=1;
	opadd.sem_flg=0;

	opaddt1.sem_num=1;
	opaddt1.sem_op=1;
	opaddt1.sem_flg=0;

while (true) {
		
		cout << "Attente que le bus soit rempli ! " << endl;
		if (semop(f_id,&opatt,1) == -1) {perror("Erreur lors de lattente !");}//Attente que toutes les places soient prises

		cout << "Debut du voyage ! " << endl;
		sleep(4);//Voyage du bus
		cout << "Fin du voyage !" << endl;
	
		
		if (semop(f_id,&oprem,1) == -1) {perror("Erreur lors de la mise a jour de la valeur du timer "); return -1;} //Timer passe a 0 , les passagers peuvent desce,dre
		cout << "Liberation des passagers " << endl;
		if (semop(f_id,&opatt2,1) == -1) {perror("Erreur lors de lattente de sortie"); return -1;}//On attend que tout le monde soit descendu
		cout << "Passagers libérés" << endl;
		if (semop(f_id,&opaddt1,1) == -1) {perror("Erreur lors de la remise en place du timer"); return -1;}//On remet le timer a 1
		cout << "Remise en place du timer" << endl;
		if (semop(f_id,&opadd,nbplace) == -1) {perror("Erreur lors de la remise en place du semaphore de sortie"); return -1;}// Il y a de nouveau toutes les places disponible
		if (semop(f_id,&opadde,nbplace) == -1) {perror("Erreur lors de la remise en place des places vides ");return -1;}//Preparation du semaphore de la prochaine descente

	}

	return 0;

}