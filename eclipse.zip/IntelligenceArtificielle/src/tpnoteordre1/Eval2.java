package tpnoteordre1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Eval2 {

	public static void main(String[] args) throws IOException {

		System.out.println("Resultats de l exercice 1 : ");
		System.out.println(" ");
		KnowledgeBase k=new KnowledgeBase("CC2-ex1.txt");
		System.out.println("Saturation de la base de faits ...");
		k.ForwardChaining();
		System.out.println(" ");
		System.out.println(k.toString());//Apres ForwardChaining

		ArrayList<Atom> exemples = new ArrayList<Atom>();
		Atom G = new Atom("G");//Atome a tester
		Atom L = new Atom("L");//Atome a tester
		Atom I = new Atom("I");//Atome a tester
		Atom E = new Atom("E");//Atome a tester
		Atom D = new Atom("D");//Atome a tester

		exemples.add(G);
		exemples.add(L);
		exemples.add(I);
		exemples.add(E);
		exemples.add(D);

		for(int i=0;i<exemples.size();i++){

			ArrayList<Atom> a = new ArrayList<Atom>();
			ArrayList<Atom> success = new ArrayList<Atom>();
			ArrayList<Atom> echec = new ArrayList<Atom>();

			System.out.println("Appel de backwardChaining pour prouver : "+exemples.get(i).toString());
			if (k.BackwardChaining(exemples.get(i),a,success,echec)) {
				System.out.println("Reponse : prouve !");
			}
			else { System.out.println("Reponse : non prouve !");
			}

		}
		
		System.out.println(" ");
		System.out.println("Resultats de l exercice 2");
		System.out.println(" ");
		
		KnowledgeBase k2=new KnowledgeBase("CC2-ex2.txt");
		System.out.println(" ");
		System.out.println("Affichage de la base de connaissances ");
		System.out.println(" ");
		System.out.println(k2.facts.toString() + k2.rules.toString());
		
		System.out.println(" ");
		System.out.println("question 2 non implémentée ");
		System.out.println(" ");
		
		k2.ForwardChaining();
		System.out.println("Base de faits saturées : ");
		System.out.println(k2.factssat.toString());
		
		System.out.println(" ");
		System.out.println("Resultats de l exercice 3 :");
		System.out.println(" ");
		
		KnowledgeBase k3=new KnowledgeBase("CC2-ex3.txt");
		
		System.out.println(k3.facts.toString()+k3.rules.toString());
		
		System.out.println(" ");
		System.out.println("question 2 non implementee ");
		System.out.println(" ");
		
		k2.ForwardChaining();
		System.out.println("Base de faits saturées : ");
		System.out.println(k3.factssat.toString());
		
	
	}
}