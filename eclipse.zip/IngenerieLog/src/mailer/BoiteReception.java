package mailer;

public class BoiteReception {
	
	public BoiteReception(){
	
	}
	
}
