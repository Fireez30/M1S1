package mailer;

public class Compactagemanuel extends Compactage {

	public Compactagemanuel(){
		
	}
	
	public String toString(){
		return " Manuel ";
	}
}
