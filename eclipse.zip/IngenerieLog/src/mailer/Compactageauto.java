package mailer;

public class Compactageauto extends Compactage {

	public Compactageauto(){
		
	}
	
	public String toString(){
		return "  Automatique ";
	}
}
