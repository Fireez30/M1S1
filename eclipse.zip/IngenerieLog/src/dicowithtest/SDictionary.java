package dicowithtest;

public class SDictionary extends AbstractDictionary {

	@Override
	protected int IndexOf(Object key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected int IndexAt(Object key) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected boolean empty() {
		// TODO Auto-generated method stub
		return false;
	}//Proche de ODico mais penser a utiliser comparable

	
}
