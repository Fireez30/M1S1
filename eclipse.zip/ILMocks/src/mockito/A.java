package mockito;

public class A {
	public int m1() {return 42;}
	public final int m2(int i){return i*i;}
}
