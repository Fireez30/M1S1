package mockito;

public interface I {
	public void methodeVoid() throws Exception;
	public int methodeInt() throws Exception;
	public int methodParam(int i);
}
